from django.urls import path
from .views import login_view, home_view, logout_view
from . import views
from django.conf.urls.static import static
from django.conf import settings
urlpatterns = [
    path('', login_view, name="login"),
    path('home/', home_view, name='home'),
    path('ficha-estudiante/', views.ficha_estudiante_view, name='ficha_estudiante'),
    path('nuevo-estudiante/', views.nuevo_estudiante_view, name='nuevo_estudiante'),
    path('buscar-estudiante/', views.buscar_estudiante, name='buscar_estudiante'),
    path('guardar-estudiante/', views.guardar_estudiante, name='guardar_estudiante'),
    path('listar-estudiantes/', views.listar_estudiantes, name='listar_estudiantes'),
    path('imprimir-estudiante/<str:rut>/', views.imprimir_estudiante, name='imprimir_estudiante'),
    path('buscar-estudiantes/', views.buscar_estudiantes_por_rut, name='buscar_estudiantes_por_rut'),
    path('detalles-estudiante/<int:estudiante_id>/', views.detalles_estudiante, name='detalles_estudiante'),
    path('descargar-documento/<int:documento_id>/', views.descargar_documento, name='descargar_documento'),
    path("crear_usuario/", views.crear_usuario_view, name="crear_usuario"),
    path("listar_usuarios/", views.listar_usuarios_view, name="listar_usuarios"),
    path("perfil_usuario/<int:usuario_id>/", views.perfil_usuario_view, name="perfil_usuario"),
    path("editar_usuario/<int:usuario_id>/", views.editar_usuario, name="editar_usuario"),
    path("listar_estudiantes_admin/", views.listar_estudiantes_admin_view, name="listar_estudiantes_admin"),
    path('imprimir_estudiantes/<str:curso>/', views.imprimir_estudiantes_por_curso, name='imprimir_estudiantes_por_curso'),
    path('logout/', logout_view, name='logout'),  # Nueva URL para cerrar sesión
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
