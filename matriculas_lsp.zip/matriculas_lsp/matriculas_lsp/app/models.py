# app/models.py

from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin

# Crear un administrador de usuarios personalizado
class UsuarioManager(BaseUserManager):
    def create_user(self, run, nombre, apellido, password=None, **extra_fields):
        """
        Crear y guardar un usuario con el RUT y la contraseña especificados.
        """
        if not run:
            raise ValueError("El RUT es obligatorio")
        user = self.model(run=run, nombre=nombre, apellido=apellido, **extra_fields)
        user.set_password(password)  # Establecer la contraseña con cifrado
        user.save(using=self._db)
        return user

    def create_superuser(self, run, nombre, apellido, password=None, **extra_fields):
        """
        Crear y guardar un superusuario con el RUT, nombre, apellido y contraseña.
        """
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError("El superusuario debe tener is_staff=True.")
        if extra_fields.get('is_superuser') is not True:
            raise ValueError("El superusuario debe tener is_superuser=True.")

        return self.create_user(run, nombre, apellido, password, **extra_fields)

class Usuarios(AbstractBaseUser, PermissionsMixin):
    ROL_CHOICES = [
        ('ADMINISTRADOR', 'Administrador'),
        ('DIRECTIVO', 'Directivo'),
        ('PROFESOR', 'Profesor'),
        ('ASISTENTE', 'Asistente'),
    ]

    id_usuario = models.AutoField(primary_key=True)
    run = models.CharField(max_length=9, unique=True)  # RUT único
    nombre = models.CharField(max_length=50)
    apellido = models.CharField(max_length=50)
    email = models.EmailField(unique=True, null=True, blank=True)
    rol = models.CharField(max_length=15, choices=ROL_CHOICES, default='ASISTENTE')
    foto_perfil = models.ImageField(upload_to='fotos_perfil/', null=True, blank=True)  # Campo para la foto de perfil
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    date_joined = models.DateTimeField(auto_now_add=True)

    USERNAME_FIELD = 'run'
    REQUIRED_FIELDS = ['nombre', 'apellido']

    objects = BaseUserManager()

    def __str__(self):
        return f"{self.nombre} {self.apellido} ({self.run}) - {self.rol}"


class Estudiante(models.Model):
    # Información del Estudiante
    rut = models.CharField(max_length=12, unique=True)  # RUT del estudiante (sin guiones ni puntos)
    nombre_completo = models.CharField(max_length=100)  # Nombre completo del estudiante
    fecha_nacimiento = models.DateField()  # Fecha de nacimiento
    sexo = models.CharField(max_length=10, choices=[('Masculino', 'Masculino'), ('Femenino', 'Femenino')])  # Sexo del estudiante
    curso = models.CharField(max_length=50)  # Asegúrate de tener este campo
    nacionalidad = models.CharField(max_length=50)  # Nacionalidad
    domicilio = models.CharField(max_length=200)  # Domicilio
    comuna = models.CharField(max_length=100)  # Comuna
    ascendencia_indigena = models.BooleanField(default=False)  # ¿Tiene ascendencia indígena?
    etnia = models.CharField(max_length=100, blank=True, null=True)  # Etnia (si tiene ascendencia indígena)
    pertenece_al_pie = models.BooleanField(default=False)  # ¿Pertenece al PIE?
    ha_repetido_curso = models.BooleanField(default=False)  # ¿Ha repetido de curso?
    estado = models.CharField(max_length=20, choices=[('Activo', 'Activo'), ('Inactivo', 'Inactivo'), ('Egresado', 'Egresado')], default='Activo')  # Estado del estudiante

    # Información de la Madre
    nombre_madre = models.CharField(max_length=100, blank=True, null=True)  # Nombre de la madre
    rut_madre = models.CharField(max_length=12, blank=True, null=True)  # RUT de la madre
    nivel_educacional_madre = models.CharField(max_length=50, blank=True, null=True)  # Nivel educacional de la madre
    ocupacion_madre = models.CharField(max_length=100, blank=True, null=True)  # Actividad que realiza la madre
    telefono_madre = models.CharField(max_length=20, blank=True, null=True)  # Número de teléfono de la madre
    email_madre = models.EmailField(max_length=100, blank=True, null=True)  # Correo electrónico de la madre

    # Información del Padre
    nombre_padre = models.CharField(max_length=100, blank=True, null=True)  # Nombre del padre
    rut_padre = models.CharField(max_length=12, blank=True, null=True)  # RUT del padre
    nivel_educacional_padre = models.CharField(max_length=50, blank=True, null=True)  # Nivel educacional del padre
    ocupacion_padre = models.CharField(max_length=100, blank=True, null=True)  # Actividad que realiza el padre
    telefono_padre = models.CharField(max_length=20, blank=True, null=True)  # Número de teléfono del padre
    email_padre = models.EmailField(max_length=100, blank=True, null=True)  # Correo electrónico del padre

    # Información del Apoderado (Opcional si es diferente a los padres)
    nombre_apoderado = models.CharField(max_length=100, blank=True, null=True)  # Nombre del apoderado
    rut_apoderado = models.CharField(max_length=12, blank=True, null=True)  # RUT del apoderado
    nivel_educacional_apoderado = models.CharField(max_length=50, blank=True, null=True)  # Nivel educacional del apoderado
    ocupacion_apoderado = models.CharField(max_length=100, blank=True, null=True)  # Actividad que realiza el apoderado
    telefono_apoderado = models.CharField(max_length=20, blank=True, null=True)  # Número de teléfono del apoderado
    email_apoderado = models.EmailField(max_length=100, blank=True, null=True)  # Correo electrónico del apoderado

    # Información del Apoderado suplente
    nombre_apoderado_suplente = models.CharField(max_length=100, blank=True, null=True)  # Nombre del apoderado
    rut_apoderado_suplente = models.CharField(max_length=12, blank=True, null=True)  # RUT del apoderado
    nivel_educacional_apoderado_suplente = models.CharField(max_length=50, blank=True, null=True)  # Nivel educacional del apoderado
    ocupacion_apoderado_suplente = models.CharField(max_length=100, blank=True, null=True)  # Actividad que realiza el apoderado
    telefono_apoderado_suplente = models.CharField(max_length=20, blank=True, null=True)  # Número de teléfono del apoderado
    email_apoderado_suplente = models.EmailField(max_length=100, blank=True, null=True)  # Correo electrónico del apoderado

    # Información Social y de Salud
    vive_con = models.CharField(max_length=50, choices=[('Ambos Padres', 'Ambos Padres'), ('Madre', 'Madre'), ('Padre', 'Padre'), ('Otros', 'Otros')])  # ¿Con quién vive el estudiante?
    resolucion_judicial = models.BooleanField(default=False)  # ¿Existe resolución judicial?
    problemas_salud = models.BooleanField(default=False)  # ¿Tiene problemas de salud?
    descripcion_problemas_salud = models.TextField(blank=True, null=True)  # Descripción de los problemas de salud (si aplica)
    impide_educacion_fisica = models.BooleanField(default=False)  # ¿Los problemas de salud impiden la educación física?
    tipo_transporte = models.CharField(max_length=100, blank=True, null=True)  # Tipo de transporte utilizado durante el año
    opta_religion = models.BooleanField(default=False)  # ¿Opta por clases de religión católica?
    acepta_fotografias = models.BooleanField(default=False)  # ¿Acepta que el hijo sea fotografiado y/o grabado?

    def __str__(self):
        return f"{self.nombre_completo} ({self.rut})"
    
class DocumentoEstudiante(models.Model):
    estudiante = models.ForeignKey(Estudiante, related_name='documentos', on_delete=models.CASCADE)
    nombre = models.CharField(max_length=255)  # Nombre del documento
    archivo = models.FileField(upload_to='documentos_estudiantes/')  # Ruta donde se guarda el archivo
    fecha_subida = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.nombre} - {self.estudiante.nombre_completo}"