from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse, HttpResponse
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from .models import Estudiante, DocumentoEstudiante, Usuarios
from .forms import LoginForm, EstudianteForm
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from io import BytesIO
from datetime import datetime
from django.http import FileResponse
from reportlab.lib import colors
from reportlab.platypus import Table, TableStyle
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Spacer, Paragraph, PageTemplate, Frame, Image, PageBreak
from reportlab.lib.styles import getSampleStyleSheet
import os 
from django.db.models import Q

# Vista de login
def login_view(request):
    form = LoginForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        run = form.cleaned_data.get('run')
        password = form.cleaned_data.get('password')
        user = authenticate(request, username=run, password=password)

        if user:
            login(request, user)
            return redirect('home')
        else:
            messages.error(request, 'Usuario o contraseña incorrectos')

    return render(request, 'app/login.html', {'form': form})

# Vista principal (home)
def home_view(request):
    return render(request, 'app/home.html')

# Vista de logout
def logout_view(request):
    logout(request)
    return redirect('login')

def ficha_estudiante_view(request):
    # Lógica de la ficha del estudiante
    return render(request, 'app/ficha_estudiante.html')


def nuevo_estudiante_view(request):
    if request.method == 'POST':
        try:
            # Extraer datos del formulario
            rut = request.POST.get('rut').strip()
            nombre_completo = request.POST.get('nombre_completo').strip()
            fecha_nacimiento = request.POST.get('fecha_nacimiento')
            sexo = request.POST.get('sexo')
            curso = request.POST.get('curso').strip()
            nacionalidad = request.POST.get('nacionalidad').strip()
            domicilio = request.POST.get('domicilio').strip()
            comuna = request.POST.get('comuna').strip()
            ascendencia_indigena = request.POST.get('ascendencia_indigena') == 'Sí'
            etnia = request.POST.get('etnia').strip()
            pertenece_al_pie = request.POST.get('pertenece_al_pie') == 'Sí'
            ha_repetido_curso = request.POST.get('ha_repetido_curso') == 'Sí'
            
            # Estado del estudiante (Activo, Inactivo, Egresado)
            estado = request.POST.get('estado').strip()

            # Información de los padres y apoderados
            nombre_madre = request.POST.get('nombre_madre').strip()
            rut_madre = request.POST.get('rut_madre').strip()
            telefono_madre = request.POST.get('telefono_madre').strip()
            nivel_educacional_madre = request.POST.get('nivel_educacional_madre').strip()
            ocupacion_madre = request.POST.get('ocupacion_madre').strip()
            email_madre = request.POST.get('email_madre').strip()

            # Información del padre
            nombre_padre = request.POST.get('nombre_padre').strip()
            rut_padre = request.POST.get('rut_padre').strip()
            telefono_padre = request.POST.get('telefono_padre').strip()
            nivel_educacional_padre = request.POST.get('nivel_educacional_padre').strip()
            ocupacion_padre = request.POST.get('ocupacion_padre').strip()
            email_padre = request.POST.get('email_padre').strip()

            # Información del apoderado
            nombre_apoderado = request.POST.get('nombre_apoderado').strip()
            rut_apoderado = request.POST.get('rut_apoderado').strip()
            telefono_apoderado = request.POST.get('telefono_apoderado').strip()
            nivel_educacional_apoderado = request.POST.get('nivel_educacional_apoderado').strip()
            ocupacion_apoderado = request.POST.get('ocupacion_apoderado').strip()
            email_apoderado = request.POST.get('email_apoderado').strip()

            # Información del apoderado suplente
            nombre_apoderado_suplente = request.POST.get('nombre_apoderado_suplente').strip()
            rut_apoderado_suplente = request.POST.get('rut_apoderado_suplente').strip()
            telefono_apoderado_suplente = request.POST.get('telefono_apoderado_suplente').strip()
            nivel_educacional_apoderado_suplente = request.POST.get('nivel_educacional_apoderado_suplente').strip()
            ocupacion_apoderado_suplente = request.POST.get('ocupacion_apoderado_suplente').strip()
            email_apoderado_suplente = request.POST.get('email_apoderado_suplente').strip()

            # Información social y de salud
            vive_con = request.POST.get('vive_con')
            resolucion_judicial = request.POST.get('resolucion_judicial') == 'Sí'
            problemas_salud = request.POST.get('problemas_salud') == 'Sí'
            descripcion_problemas_salud = request.POST.get('descripcion_problemas_salud').strip()
            impide_educacion_fisica = request.POST.get('impide_educacion_fisica') == 'Sí'

            # Transporte y otros aspectos
            tipo_transporte = request.POST.get('tipo_transporte').strip()
            opta_religion = request.POST.get('opta_religion') == 'Sí'
            acepta_fotografias = request.POST.get('acepta_fotografias') == 'Sí'

            # Crear nuevo estudiante en la base de datos
            estudiante = Estudiante(
                rut=rut,
                nombre_completo=nombre_completo,
                fecha_nacimiento=fecha_nacimiento,
                sexo=sexo,
                curso=curso,
                nacionalidad=nacionalidad,
                domicilio=domicilio,
                comuna=comuna,
                ascendencia_indigena=ascendencia_indigena,
                etnia=etnia,
                pertenece_al_pie=pertenece_al_pie,
                ha_repetido_curso=ha_repetido_curso,
                estado=estado,  # <-- Añadir el campo estado aquí
                nombre_madre=nombre_madre,
                rut_madre=rut_madre,
                telefono_madre=telefono_madre,
                nivel_educacional_madre=nivel_educacional_madre,
                ocupacion_madre=ocupacion_madre,
                email_madre=email_madre,
                nombre_padre=nombre_padre,
                rut_padre=rut_padre,
                telefono_padre=telefono_padre,
                nivel_educacional_padre=nivel_educacional_padre,
                ocupacion_padre=ocupacion_padre,
                email_padre=email_padre,
                nombre_apoderado=nombre_apoderado,
                rut_apoderado=rut_apoderado,
                telefono_apoderado=telefono_apoderado,
                nivel_educacional_apoderado=nivel_educacional_apoderado,
                ocupacion_apoderado=ocupacion_apoderado,
                email_apoderado=email_apoderado,
                nombre_apoderado_suplente=nombre_apoderado_suplente,
                rut_apoderado_suplente=rut_apoderado_suplente,
                telefono_apoderado_suplente=telefono_apoderado_suplente,
                nivel_educacional_apoderado_suplente=nivel_educacional_apoderado_suplente,
                ocupacion_apoderado_suplente=ocupacion_apoderado_suplente,
                email_apoderado_suplente=email_apoderado_suplente,
                vive_con=vive_con,
                resolucion_judicial=resolucion_judicial,
                problemas_salud=problemas_salud,
                descripcion_problemas_salud=descripcion_problemas_salud,
                impide_educacion_fisica=impide_educacion_fisica,
                tipo_transporte=tipo_transporte,
                opta_religion=opta_religion,
                acepta_fotografias=acepta_fotografias
            )

            estudiante.save()
            messages.success(request, 'Estudiante creado correctamente.')
            return redirect('nuevo_estudiante')

        except Exception as e:
            messages.error(request, f'Ocurrió un error al guardar el estudiante: {str(e)}')
            return render(request, 'app/nuevo_estudiante.html')

    # En caso de ser GET, renderizar la plantilla
    return render(request, 'app/nuevo_estudiante.html')


def buscar_estudiante(request):
    if request.method == 'GET':
        rut = request.GET.get('rut')
        
        # Verificar si `rut` fue proporcionado en la solicitud
        if rut:
            rut = rut.strip()  # Solo intenta hacer `strip()` si `rut` no es `None`
            try:
                estudiante = Estudiante.objects.get(rut=rut)
                data = {
                    'rut': estudiante.rut,
                    'nombre_completo': estudiante.nombre_completo,
                    'fecha_nacimiento': estudiante.fecha_nacimiento.strftime('%Y-%m-%d') if estudiante.fecha_nacimiento else '',
                    'sexo': estudiante.sexo,
                    'curso': estudiante.curso,
                    'nacionalidad': estudiante.nacionalidad,
                    'domicilio': estudiante.domicilio,
                    'comuna': estudiante.comuna,
                    'ascendencia_indigena': 'Sí' if estudiante.ascendencia_indigena else 'No',
                    'etnia': estudiante.etnia or '',
                    'pertenece_al_pie': 'Sí' if estudiante.pertenece_al_pie else 'No',
                    'ha_repetido_curso': 'Sí' if estudiante.ha_repetido_curso else 'No',
                    'estado': estudiante.estado,  # <-- Añadir el estado aquí
                    'vive_con': estudiante.vive_con,
                    'resolucion_judicial': 'Sí' if estudiante.resolucion_judicial else 'No',
                    'problemas_salud': 'Sí' if estudiante.problemas_salud else 'No',
                    'descripcion_problemas_salud': estudiante.descripcion_problemas_salud or '',
                    'impide_educacion_fisica': 'Sí' if estudiante.impide_educacion_fisica else 'No',
                    'tipo_transporte': estudiante.tipo_transporte or '',
                    'opta_religion': 'Sí' if estudiante.opta_religion else 'No',
                    'acepta_fotografias': 'Sí' if estudiante.acepta_fotografias else 'No',
                    
                    # Información de la madre
                    'nombre_madre': estudiante.nombre_madre or '',
                    'rut_madre': estudiante.rut_madre or '',
                    'nivel_educacional_madre': estudiante.nivel_educacional_madre or '',
                    'ocupacion_madre': estudiante.ocupacion_madre or '',
                    'telefono_madre': estudiante.telefono_madre or '',
                    'email_madre': estudiante.email_madre or '',
                    
                    # Información del padre
                    'nombre_padre': estudiante.nombre_padre or '',
                    'rut_padre': estudiante.rut_padre or '',
                    'nivel_educacional_padre': estudiante.nivel_educacional_padre or '',
                    'ocupacion_padre': estudiante.ocupacion_padre or '',
                    'telefono_padre': estudiante.telefono_padre or '',
                    'email_padre': estudiante.email_padre or '',
                    
                    # Información del apoderado
                    'nombre_apoderado': estudiante.nombre_apoderado or '',
                    'rut_apoderado': estudiante.rut_apoderado or '',
                    'nivel_educacional_apoderado': estudiante.nivel_educacional_apoderado or '',
                    'ocupacion_apoderado': estudiante.ocupacion_apoderado or '',
                    'telefono_apoderado': estudiante.telefono_apoderado or '',
                    'email_apoderado': estudiante.email_apoderado or '',

                    # Información del apoderado suplente
                    'nombre_apoderado_suplente': estudiante.nombre_apoderado_suplente or '',
                    'rut_apoderado_suplente': estudiante.rut_apoderado_suplente or '',
                    'nivel_educacional_apoderado_suplente': estudiante.nivel_educacional_apoderado_suplente or '',
                    'ocupacion_apoderado_suplente': estudiante.ocupacion_apoderado_suplente or '',
                    'telefono_apoderado_suplente': estudiante.telefono_apoderado_suplente or '',
                    'email_apoderado_suplente': estudiante.email_apoderado_suplente or '',
                }
                return JsonResponse({'status': 'success', 'data': data})
            except Estudiante.DoesNotExist:
                return JsonResponse({'status': 'error', 'message': 'No se encontró un estudiante con ese RUT.'})
        else:
            return JsonResponse({'status': 'error', 'message': 'Debe proporcionar un RUT válido.'})
    return JsonResponse({'status': 'error', 'message': 'Método no permitido.'})


def guardar_estudiante(request):
    if request.method == 'POST':
        rut = request.POST.get('rut', '').strip()

        # Validar si se ha proporcionado un RUT
        if not rut:
            messages.error(request, 'El RUT es un campo obligatorio.')
            return redirect('nuevo_estudiante')

        # Obtener o crear el estudiante por RUT
        estudiante, created = Estudiante.objects.get_or_create(rut=rut)

        try:
            # Asignar los datos del formulario al modelo
            estudiante.nombre_completo = request.POST.get('nombre_completo', '').strip()
            
            fecha_nacimiento_str = request.POST.get('fecha_nacimiento', '').strip()
            if fecha_nacimiento_str:
                estudiante.fecha_nacimiento = datetime.strptime(fecha_nacimiento_str, '%Y-%m-%d').date()
            else:
                messages.error(request, 'La fecha de nacimiento es un campo obligatorio.')
                return redirect('home')

            estudiante.sexo = request.POST.get('sexo', '').strip()
            estudiante.curso = request.POST.get('curso', '').strip()
            estudiante.nacionalidad = request.POST.get('nacionalidad', '').strip()
            estudiante.domicilio = request.POST.get('domicilio', '').strip()
            estudiante.comuna = request.POST.get('comuna', '').strip()
            estudiante.ascendencia_indigena = request.POST.get('ascendencia_indigena') == 'Sí'
            estudiante.etnia = request.POST.get('etnia', '').strip()
            estudiante.estado = request.POST.get('estado', '').strip()  # <-- Añadir el campo estado aquí

            # Información de la madre
            estudiante.nombre_madre = request.POST.get('nombre_madre', '').strip()
            estudiante.rut_madre = request.POST.get('rut_madre', '').strip()
            estudiante.telefono_madre = request.POST.get('telefono_madre', '').strip()
            estudiante.nivel_educacional_madre = request.POST.get('nivel_educacional_madre', '').strip()
            estudiante.ocupacion_madre = request.POST.get('ocupacion_madre', '').strip()
            estudiante.email_madre = request.POST.get('email_madre', '').strip()

            # Información del padre
            estudiante.nombre_padre = request.POST.get('nombre_padre', '').strip()
            estudiante.rut_padre = request.POST.get('rut_padre', '').strip()
            estudiante.telefono_padre = request.POST.get('telefono_padre', '').strip()
            estudiante.nivel_educacional_padre = request.POST.get('nivel_educacional_padre', '').strip()
            estudiante.ocupacion_padre = request.POST.get('ocupacion_padre', '').strip()
            estudiante.email_padre = request.POST.get('email_padre', '').strip()

            # Información del apoderado principal
            estudiante.nombre_apoderado = request.POST.get('nombre_apoderado', '').strip()
            estudiante.rut_apoderado = request.POST.get('rut_apoderado', '').strip()
            estudiante.telefono_apoderado = request.POST.get('telefono_apoderado', '').strip()
            estudiante.nivel_educacional_apoderado = request.POST.get('nivel_educacional_apoderado', '').strip()
            estudiante.ocupacion_apoderado = request.POST.get('ocupacion_apoderado', '').strip()
            estudiante.email_apoderado = request.POST.get('email_apoderado', '').strip()

            # Información del apoderado suplente
            estudiante.nombre_apoderado_suplente = request.POST.get('nombre_apoderado_suplente', '').strip()
            estudiante.rut_apoderado_suplente = request.POST.get('rut_apoderado_suplente', '').strip()
            estudiante.telefono_apoderado_suplente = request.POST.get('telefono_apoderado_suplente', '').strip()
            estudiante.nivel_educacional_apoderado_suplente = request.POST.get('nivel_educacional_apoderado_suplente', '').strip()
            estudiante.ocupacion_apoderado_suplente = request.POST.get('ocupacion_apoderado_suplente', '').strip()
            estudiante.email_apoderado_suplente = request.POST.get('email_apoderado_suplente', '').strip()

            # Información social y de salud
            estudiante.vive_con = request.POST.get('vive_con', '').strip()
            estudiante.resolucion_judicial = request.POST.get('resolucion_judicial') == 'Sí'
            estudiante.problemas_salud = request.POST.get('problemas_salud') == 'Sí'
            estudiante.descripcion_problemas_salud = request.POST.get('descripcion_problemas_salud', '').strip()
            estudiante.impide_educacion_fisica = request.POST.get('impide_educacion_fisica') == 'Sí'

            # Transporte y otros aspectos
            estudiante.tipo_transporte = request.POST.get('tipo_transporte', '').strip()
            estudiante.opta_religion = request.POST.get('opta_religion') == 'No'  # Ajusta la lógica según tus opciones
            estudiante.acepta_fotografias = request.POST.get('acepta_fotografias') == 'Sí'

            # Guardar cambios en la base de datos
            estudiante.save()

            messages.success(request, 'Estudiante actualizado correctamente.')

        except Exception as e:
            messages.error(request, f'Error al guardar el estudiante: {str(e)}')

        return redirect('home')

    return redirect('home')


def listar_estudiantes(request):
    # Definir los cursos disponibles
    cursos_basica = [
        'Prekinder', 'Kinder', '1° Básico', '2° Básico', '3° Básico', '4° Básico',
        '5° Básico', '6° Básico', '7° Básico', '8° Básico'
    ]
    cursos_media = [
        '1° Medio', '2° Medio', '3° Medio', '4° Medio'
    ]

    # Filtrar estudiantes por curso si se selecciona uno
    curso_seleccionado = request.GET.get('curso')
    if curso_seleccionado:
        estudiantes = Estudiante.objects.filter(curso=curso_seleccionado).exclude(estado='Egresado')
    else:
        estudiantes = Estudiante.objects.exclude(estado='Egresado')

    # Manejar la subida de documentos si se realiza una solicitud POST
    if request.method == 'POST':
        estudiante_id = request.POST.get('estudiante_id')
        estudiante = get_object_or_404(Estudiante, id=estudiante_id)

        archivo = request.FILES.get('archivo')
        if archivo:
            documento = DocumentoEstudiante(
                estudiante=estudiante,
                nombre=archivo.name,
                archivo=archivo
            )
            documento.save()
            # Añadir mensaje de éxito
            messages.success(request, f'El documento "{archivo.name}" se subió correctamente para el estudiante {estudiante.nombre_completo}.')
            return redirect('listar_estudiantes')

    return render(request, 'app/listar_estudiantes.html', {
        'cursos_basica': cursos_basica,
        'cursos_media': cursos_media,
        'estudiantes': estudiantes,
        'curso_seleccionado': curso_seleccionado,
    })



def imprimir_estudiante(request, rut):
    estudiante = get_object_or_404(Estudiante, rut=rut)

    # Crear un buffer para el archivo PDF
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=30, leftMargin=30, topMargin=30, bottomMargin=30)
    elements = []
    styles = getSampleStyleSheet()

    # Logo y encabezado
    def agregar_encabezado():
        logo_path = './app/static/app/img/logo.png'  # Ajusta el path del logo
        logo = Image(logo_path, width=40, height=40)  # Reducir tamaño del logo
        encabezado = Paragraph(
            "LICEO MUNICIPAL DE SAN PEDRO<br/>"
            "R.B.D 10854-5. Carretera de la Fruta km 9.5, San Pedro de Melipilla.<br/>"
            "Provincia de Melipilla, Región Metropolitana.",
            styles['Normal']
        )
        encabezado_style = styles['Normal']
        encabezado_style.fontSize = 8  # Reducir el tamaño del texto del encabezado
        encabezado_style.alignment = 1  # Centrar el encabezado

        elements.append(logo)
        elements.append(Spacer(1, 10))
        elements.append(encabezado)
        elements.append(Spacer(1, 20))

    # Agregar el encabezado inicial
    agregar_encabezado()

    # Título del documento
    ficha_title = Paragraph("FICHA DE INSCRIPCIÓN DE MATRÍCULA 2024", styles['Heading1'])
    ficha_title_style = styles['Heading1']
    ficha_title_style.alignment = 1  # Centrar el título
    elements.append(ficha_title)
    elements.append(Spacer(1, 12))

    # Información del estudiante
    data_estudiante = [
        ['RUT', estudiante.rut, 'Curso', estudiante.curso],
        ['Nombre Completo', estudiante.nombre_completo, 'Fecha de Nacimiento', estudiante.fecha_nacimiento.strftime('%d-%m-%Y')],
        ['Sexo', estudiante.sexo, 'Nacionalidad', estudiante.nacionalidad],
        ['Domicilio', estudiante.domicilio, 'Comuna', estudiante.comuna],
        ['Ascendencia Indígena', 'Sí' if estudiante.ascendencia_indigena else 'No', '¿Ha Repetido Curso?', 'Sí' if estudiante.ha_repetido_curso else 'No'],
        ['Pertenece al PIE', 'Sí' if estudiante.pertenece_al_pie else 'No', '', '']
    ]
    table_estudiante = Table(data_estudiante, colWidths=[150, 150, 120, 150])
    table_estudiante.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
    ]))
    elements.append(table_estudiante)
    elements.append(Spacer(1, 55))

    # Información de los padres
    data_padres = [
        ['Nombre de la Madre', estudiante.nombre_madre or 'N/A', 'RUT de la Madre', estudiante.rut_madre or 'N/A'],
        ['Teléfono de la Madre', estudiante.telefono_madre or 'N/A', 'Nivel Educacional Madre', estudiante.nivel_educacional_madre or 'N/A'],
        ['Ocupación de la Madre', estudiante.ocupacion_madre or 'N/A', '', ''],
        ['Nombre del Padre', estudiante.nombre_padre or 'N/A', 'RUT del Padre', estudiante.rut_padre or 'N/A'],
        ['Teléfono del Padre', estudiante.telefono_padre or 'N/A', 'Nivel Educacional Padre', estudiante.nivel_educacional_padre or 'N/A'],
        ['Ocupación del Padre', estudiante.ocupacion_padre or 'N/A', '', '']
    ]
    table_padres = Table(data_padres, colWidths=[150, 150, 150, 100])
    table_padres.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
    ]))
    elements.append(table_padres)
    elements.append(Spacer(1, 55))

    # Información del apoderado
    data_apoderado = [
        ['Nombre del Apoderado', estudiante.nombre_apoderado or 'N/A', 'RUT del Apoderado', estudiante.rut_apoderado or 'N/A'],
        ['Teléfono del Apoderado', estudiante.telefono_apoderado or 'N/A', 'Nivel Educacional Apoderado', estudiante.nivel_educacional_apoderado or 'N/A'],
        ['Ocupación del Apoderado', estudiante.ocupacion_apoderado or 'N/A', '', '']
    ]
    table_apoderado = Table(data_apoderado, colWidths=[150, 150, 150, 100])
    table_apoderado.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
    ]))
    elements.append(table_apoderado)
    elements.append(Spacer(1, 55))

    # Información del apoderado suplente
    data_apoderado_suplente = [
        ['Nombre del Apoderado Suplente', estudiante.nombre_apoderado_suplente or 'N/A'],
        ['RUT del Apoderado Suplente', estudiante.rut_apoderado_suplente or 'N/A'],
        ['Teléfono del Apoderado Suplente', estudiante.telefono_apoderado_suplente or 'N/A'],
        ['Nivel Educacional Apoderado Suplente', estudiante.nivel_educacional_apoderado_suplente or 'N/A'],
        ['Ocupación del Apoderado Suplente', estudiante.ocupacion_apoderado_suplente or 'N/A']
    ]
    table_apoderado_suplente = Table(data_apoderado_suplente, colWidths=[200, 300])
    table_apoderado_suplente.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
    ]))
    elements.append(table_apoderado_suplente)
    elements.append(Spacer(1, 55))

    # Salto de página y encabezado para la nueva hoja
    elements.append(PageBreak())
    agregar_encabezado()

    # Información social y de salud
    data_salud = [
        ['Vive con', estudiante.vive_con, 'Resolución Judicial', 'Sí' if estudiante.resolucion_judicial else 'No'],
        ['Problemas de Salud', 'Sí' if estudiante.problemas_salud else 'No', 'Descripción', estudiante.descripcion_problemas_salud if estudiante.problemas_salud else 'N/A'],
        ['Impide Educación Física', 'Sí' if estudiante.impide_educacion_fisica else 'No', '', '']
    ]
    table_salud = Table(data_salud, colWidths=[150, 150, 150, 100])
    table_salud.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
    ]))
    elements.append(table_salud)
    elements.append(Spacer(1, 55))

    # Transporte y otros aspectos
    data_transporte = [
        ['Tipo de Transporte', estudiante.tipo_transporte or 'N/A', 'Opta por clases de religión', 'Sí' if estudiante.opta_religion else 'No'],
        ['Acepta Fotografías', 'Sí' if estudiante.acepta_fotografias else 'No', '', '']
    ]
    table_transporte = Table(data_transporte, colWidths=[150, 150, 150, 100])
    table_transporte.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
    ]))
    elements.append(table_transporte)
    elements.append(Spacer(1, 55))

    # Firmas al final de la última hoja con la firma escaneada del director
    firma_path = './app/static/app/img/firma_director.jpeg'  # Ajusta el path de la firma escaneada
    firma_director_img = Image(firma_path, width=100, height=50)  # Imagen de la firma del director

# Tabla de firmas con la firma del director
    firma_director = Paragraph("Firma Director:", styles['Normal'])
    firma_apoderado = Paragraph("Firma Apoderado: ___________________________", styles['Normal'])

    # Nueva tabla de firmas con ajustes para colocar la imagen al lado del texto
    firma_table = Table([
        [firma_director, firma_director_img, firma_apoderado]
    ], colWidths=[100, 150, 250])

    firma_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),  # Alineación vertical en el medio para que la firma esté al lado del texto
        ('BOTTOMPADDING', (0, 0), (-1, -1), 0),  # Reducir padding para evitar espacio excesivo
        ('TOPPADDING', (0, 0), (-1, -1), 0),  # Reducir padding para que la firma esté más alineada
        ('LEFTPADDING', (1, 0), (1, 0), -20)  # Ajustar padding izquierdo de la imagen para acercarla al texto "Firma Director"
    ]))

    elements.append(Spacer(1, 50))  # Espacio para mover las firmas más abajo, si es necesario
    elements.append(firma_table)

    # Construir el PDF
    doc.build(elements)

    # Devolver el PDF como respuesta
    buffer.seek(0)
    return FileResponse(buffer, as_attachment=True, filename=f'ficha_estudiante_{estudiante.rut}.pdf')



def buscar_estudiantes_por_rut(request):
    rut = request.GET.get('rut', '').strip()
    estudiantes = Estudiante.objects.filter(rut__icontains=rut) if rut else []
    estudiantes_data = [
        {
            'rut': estudiante.rut,
            'nombre_completo': estudiante.nombre_completo,
            'curso': estudiante.curso
        } for estudiante in estudiantes
    ]
    return JsonResponse(estudiantes_data, safe=False)

def detalles_estudiante(request, estudiante_id):
    estudiante = get_object_or_404(Estudiante, id=estudiante_id)
    documentos = DocumentoEstudiante.objects.filter(estudiante=estudiante)

    return render(request, 'app/detalles_estudiante.html', {'estudiante': estudiante, 'documentos': documentos})

def descargar_documento(request, documento_id):
    documento = get_object_or_404(DocumentoEstudiante, id=documento_id)
    response = FileResponse(documento.archivo, as_attachment=True, filename=documento.nombre)
    return response


def crear_usuario_view(request):
    # Solo el administrador puede acceder a esta vista
    if request.user.rol != 'ADMINISTRADOR':
        messages.error(request, "No tienes permiso para crear usuarios.")
        return redirect("home")
    
    if request.method == "POST":
        run = request.POST.get('run').strip()
        nombre = request.POST.get('nombre').strip()
        apellido = request.POST.get('apellido').strip()
        email = request.POST.get('email').strip()
        password = request.POST.get('password').strip()
        rol = request.POST.get('rol').strip()

        # Crear el usuario
        try:
            usuario = Usuarios(run=run, nombre=nombre, apellido=apellido, email=email, rol=rol)
            usuario.set_password(password)
            usuario.save()
            messages.success(request, "Usuario creado exitosamente.")
            return redirect("home")
        except Exception as e:
            messages.error(request, f"Error al crear el usuario: {str(e)}")
    
    return render(request, "app/crear_usuario.html")

def listar_usuarios_view(request):
    # Solo el administrador puede ver la lista completa de usuarios
    if request.user.rol != 'ADMINISTRADOR':
        return redirect("home")
    
    usuarios = Usuarios.objects.all()
    return render(request, "app/listar_usuarios.html", {"usuarios": usuarios})


def editar_usuario(request, usuario_id):
    # Obtener el usuario a editar
    usuario = get_object_or_404(Usuarios, id_usuario=usuario_id)
    
    if request.method == "POST":
        # Usar valores por defecto vacíos para evitar errores de None
        nombre = request.POST.get('nombre', '').strip()
        apellido = request.POST.get('apellido', '').strip()
        email = request.POST.get('email', '').strip()
        rol = request.POST.get('rol', '').strip()

        if nombre:
            usuario.nombre = nombre
        if apellido:
            usuario.apellido = apellido
        if email:
            usuario.email = email
        if rol:
            usuario.rol = rol

        # Guardar cambios en el usuario
        usuario.save()
        return redirect("perfil_usuario", usuario_id=usuario.id_usuario)
    
    # Retornar a la vista de perfil
    return render(request, "app/perfil_usuario.html", {"usuario": usuario})

def perfil_usuario_view(request, usuario_id):
    # Obtener el usuario por ID
    usuario = get_object_or_404(Usuarios, id_usuario=usuario_id)

    # Actualizar foto de perfil si se envía
    if request.method == "POST" and 'foto_perfil' in request.FILES:
        usuario.foto_perfil = request.FILES['foto_perfil']
        usuario.save()
        messages.success(request, "Foto de perfil actualizada exitosamente.")
        return redirect('perfil_usuario', usuario_id=usuario.id_usuario)
    
    # Actualizar información del usuario
    if request.method == "POST":
        nombre = request.POST.get('nombre', '').strip()
        apellido = request.POST.get('apellido', '').strip()
        email = request.POST.get('email', '').strip()
        rol = request.POST.get('rol', '').strip()
        password = request.POST.get('password', '').strip()

        if nombre:
            usuario.nombre = nombre
        if apellido:
            usuario.apellido = apellido
        if email:
            usuario.email = email
        if rol:
            usuario.rol = rol
        if password:
            usuario.set_password(password)
        
        usuario.save()
        messages.success(request, "Información del usuario actualizada exitosamente.")
        return redirect('app/listar_usuarios.html')
    
    return render(request, "app/perfil_usuario.html", {"usuario": usuario})

def listar_estudiantes_admin_view(request):
    # Solo el administrador puede acceder a esta vista
    if not request.user.is_superuser:
        return redirect("home")
    
    # Listar todos los estudiantes
    estudiantes = Estudiante.objects.all()

    # Filtrar los cursos para enseñanza básica y media
    cursos_basica = ['Prekinder', 'Kinder'] + [f"{i}° Básico" for i in range(1, 9)]
    cursos_media = [f"{i}° Medio" for i in range(1, 5)]

    # Renderizar la plantilla con los estudiantes y los cursos
    return render(request, "app/estudiantes_admin.html", {
        "estudiantes": estudiantes,
        "cursos_basica": cursos_basica,
        "cursos_media": cursos_media,
    })

def imprimir_estudiantes_por_curso(request, curso):
    # Filtrar los estudiantes por curso
    estudiantes = Estudiante.objects.filter(curso=curso, estado="Activo")  # Considerando solo los estudiantes activos

    # Crear un buffer para el archivo PDF
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=30, leftMargin=30, topMargin=30, bottomMargin=30)
    elements = []
    styles = getSampleStyleSheet()

    # Logo y encabezado
    def agregar_encabezado():
        logo_path = './app/static/app/img/logo.png'  # Ajusta el path del logo
        logo = Image(logo_path, width=40, height=40)  # Reducir tamaño del logo
        encabezado = Paragraph(
            "LICEO MUNICIPAL DE SAN PEDRO<br/>"
            "R.B.D 10854-5. Carretera de la Fruta km 9.5, San Pedro de Melipilla.<br/>"
            "Provincia de Melipilla, Región Metropolitana.",
            styles['Normal']
        )
        encabezado_style = styles['Normal']
        encabezado_style.fontSize = 8  # Reducir el tamaño del texto del encabezado
        encabezado_style.alignment = 1  # Centrar el encabezado

        elements.append(logo)
        elements.append(Spacer(1, 10))
        elements.append(encabezado)
        elements.append(Spacer(1, 20))

    # Título del documento
    ficha_title = Paragraph(f"LISTADO DE ESTUDIANTES - CURSO {curso.upper()}", styles['Heading1'])
    ficha_title_style = styles['Heading1']
    ficha_title_style.alignment = 1  # Centrar el título
    elements.append(ficha_title)
    elements.append(Spacer(1, 12))

    # Iterar sobre cada estudiante del curso
    for estudiante in estudiantes:
        # Agregar encabezado inicial para cada estudiante
        agregar_encabezado()

        # Información del estudiante
        data_estudiante = [
            ['RUT', estudiante.rut, 'Curso', estudiante.curso],
            ['Nombre Completo', estudiante.nombre_completo, 'Fecha de Nacimiento', estudiante.fecha_nacimiento.strftime('%d-%m-%Y')],
            ['Sexo', estudiante.sexo, 'Nacionalidad', estudiante.nacionalidad],
            ['Domicilio', estudiante.domicilio, 'Comuna', estudiante.comuna],
            ['Ascendencia Indígena', 'Sí' if estudiante.ascendencia_indigena else 'No', '¿Ha Repetido Curso?', 'Sí' if estudiante.ha_repetido_curso else 'No'],
            ['Pertenece al PIE', 'Sí' if estudiante.pertenece_al_pie else 'No', '', '']
        ]
        table_estudiante = Table(data_estudiante, colWidths=[150, 150, 120, 150])
        table_estudiante.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ]))
        elements.append(table_estudiante)
        elements.append(Spacer(1, 55))

        # Información de los padres
        data_padres = [
            ['Nombre de la Madre', estudiante.nombre_madre or 'N/A', 'RUT de la Madre', estudiante.rut_madre or 'N/A'],
            ['Teléfono de la Madre', estudiante.telefono_madre or 'N/A', 'Nivel Educacional Madre', estudiante.nivel_educacional_madre or 'N/A'],
            ['Ocupación de la Madre', estudiante.ocupacion_madre or 'N/A', '', ''],
            ['Nombre del Padre', estudiante.nombre_padre or 'N/A', 'RUT del Padre', estudiante.rut_padre or 'N/A'],
            ['Teléfono del Padre', estudiante.telefono_padre or 'N/A', 'Nivel Educacional Padre', estudiante.nivel_educacional_padre or 'N/A'],
            ['Ocupación del Padre', estudiante.ocupacion_padre or 'N/A', '', '']
        ]
        table_padres = Table(data_padres, colWidths=[150, 150, 150, 100])
        table_padres.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ]))
        elements.append(table_padres)
        elements.append(Spacer(1, 55))

        # Información del apoderado
        data_apoderado = [
            ['Nombre del Apoderado', estudiante.nombre_apoderado or 'N/A', 'RUT del Apoderado', estudiante.rut_apoderado or 'N/A'],
            ['Teléfono del Apoderado', estudiante.telefono_apoderado or 'N/A', 'Nivel Educacional Apoderado', estudiante.nivel_educacional_apoderado or 'N/A'],
            ['Ocupación del Apoderado', estudiante.ocupacion_apoderado or 'N/A', '', '']
        ]
        table_apoderado = Table(data_apoderado, colWidths=[150, 150, 150, 100])
        table_apoderado.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ]))
        elements.append(table_apoderado)
        elements.append(Spacer(1, 55))

        # Información del apoderado suplente
        data_apoderado_suplente = [
            ['Nombre del Apoderado Suplente', estudiante.nombre_apoderado_suplente or 'N/A'],
            ['RUT del Apoderado Suplente', estudiante.rut_apoderado_suplente or 'N/A'],
            ['Teléfono del Apoderado Suplente', estudiante.telefono_apoderado_suplente or 'N/A'],
            ['Nivel Educacional Apoderado Suplente', estudiante.nivel_educacional_apoderado_suplente or 'N/A'],
            ['Ocupación del Apoderado Suplente', estudiante.ocupacion_apoderado_suplente or 'N/A']
        ]
        table_apoderado_suplente = Table(data_apoderado_suplente, colWidths=[200, 300])
        table_apoderado_suplente.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ]))
        elements.append(table_apoderado_suplente)
        elements.append(Spacer(1, 55))

        # Información social y de salud
        data_salud = [
            ['Vive con', estudiante.vive_con, 'Resolución Judicial', 'Sí' if estudiante.resolucion_judicial else 'No'],
            ['Problemas de Salud', 'Sí' if estudiante.problemas_salud else 'No', 'Descripción', estudiante.descripcion_problemas_salud if estudiante.problemas_salud else 'N/A'],
            ['Impide Educación Física', 'Sí' if estudiante.impide_educacion_fisica else 'No', '', '']
        ]
        table_salud = Table(data_salud, colWidths=[150, 150, 150, 100])
        table_salud.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ]))
        elements.append(table_salud)
        elements.append(Spacer(1, 55))

        # Transporte y otros aspectos
        data_transporte = [
            ['Tipo de Transporte', estudiante.tipo_transporte or 'N/A', 'Opta por clases de religión', 'Sí' if estudiante.opta_religion else 'No'],
            ['Acepta Fotografías', 'Sí' if estudiante.acepta_fotografias else 'No', '', '']
        ]
        table_transporte = Table(data_transporte, colWidths=[150, 150, 150, 100])
        table_transporte.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ]))
        elements.append(table_transporte)
        elements.append(Spacer(1, 55))

        # Salto de página para el siguiente estudiante, si no es el último
        if estudiante != estudiantes.last():
            elements.append(PageBreak())

    # Construir el PDF
    doc.build(elements)

    # Devolver el PDF como respuesta
    buffer.seek(0)
    return FileResponse(buffer, as_attachment=True, filename=f'listado_estudiantes_{curso}.pdf')