# app/forms.py

from django import forms
from .models import Estudiante

class LoginForm(forms.Form):
    run = forms.CharField(
        max_length=9,
        label='RUT',
        widget=forms.TextInput(attrs={'placeholder': 'RUT', 'required': True})
    )
    password = forms.CharField(
        label='Contraseña',
        widget=forms.PasswordInput(attrs={'placeholder': 'Contraseña', 'required': True})
    )

class EstudianteForm(forms.ModelForm):
    fecha_nacimiento = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))  # Renderizar con un input de tipo date
    class Meta:
        model = Estudiante
        fields = [
            'rut', 'nombre_completo', 'fecha_nacimiento', 'sexo', 'nacionalidad', 'domicilio', 'comuna',
            'ascendencia_indigena', 'etnia', 'pertenece_al_pie', 'ha_repetido_curso',
            'nombre_madre', 'rut_madre', 'nivel_educacional_madre', 'ocupacion_madre', 'telefono_madre', 'email_madre',
            'nombre_padre', 'rut_padre', 'nivel_educacional_padre', 'ocupacion_padre', 'telefono_padre', 'email_padre',
            'nombre_apoderado', 'rut_apoderado', 'nivel_educacional_apoderado', 'ocupacion_apoderado', 'telefono_apoderado', 'email_apoderado',
            'vive_con', 'resolucion_judicial', 'problemas_salud', 'descripcion_problemas_salud', 'impide_educacion_fisica',
            'tipo_transporte', 'opta_religion', 'acepta_fotografias'
        ]